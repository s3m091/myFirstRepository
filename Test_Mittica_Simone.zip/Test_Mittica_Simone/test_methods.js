//problema 1

function faiSomma(){

	var num=0;
	var div1=3;
	var div2=5;
	var numSomma=0;

	while (num<1000){
		if(num%div1==0 || num%div2==0){
			numSomma = numSomma + num;
			num++;
		}else{
			num++;
		}
	}

	var result = document.getElementById("risultato");
	result.innerHTML = numSomma;
}

//problema 2

function faiSommaNumeriPrimi(){

	var num;
	var div;
	var numSomma=0;

	for (num=2;num<2000000;num++) {
        for (div=2;div<=num/2;div++) {
            if (num%div == 0) {
                break;
            }
        }
        if (num%div != 0) {
            numSomma = numSomma + num;
        }
        if (num==2){
        	numSomma = numSomma + num;
        }
    }

	var result = document.getElementById("risultatoNumeriPrimi");
	result.innerHTML = numSomma;	
}

//problema 3

function contaTerminiSequenza(){

	//metodo per inserimento numero

	var number = document.getElementById("numero");
	var i = 0;

	var num = parseInt(number.value);

	while(num!=1){
		if(num%2==0){
			num=num/2;
			i++;
		}else{
			num=num*3+1;
			i++;
		}
	}

	if(num==1){
		i++;
	}

	var result = document.getElementById("risultatoSequenza");
	result.innerHTML = i;
	
	
	/*
	//metodo per calcolo automatico

	var num = 1;
	var i = 0;

	for(num; num<10; num++){

		while(num!=1){
			if(num%2==0){
				num=num/2;
				i++;
			}else{
				num=num*3+1;
				i++;
			}
		}

		if(num==1){
			i++;
		}

	}

	document.write("Per il numero "+ num +", il numero di sequenze è "+ i);
	//var result = document.getElementById("risultatoSequenza");
	//result.innerHTML = "Per il numero "+num+", il numero di sequenze è "+i;
	*/
}


//problema 4

function contaFibonacci(){
	var n1=1;
	var n2=1;
	var num=3;
	var num2=0;

	for(num;num2<=1000;num++){

		if(num==3){
			n3=n1+n2;
			num2=n3;
		}

		if(num==4){
			n4=n3+n2;
			num2=n4;
		}

		if(num==5){
			num2=n3+n4;
		}

		if(num>5){
			n3=n4;
			n4=num2;
			num2=n3+n4;
		}

		//document.write("Il numero "+ num +" corrisponde a "+ num2 + " secondo Fibonacci <br>");
	}

	var result = document.getElementById("termineFibonacci");
	var result2 = document.getElementById("risultatoFibonacci");
	result.innerHTML = num-1;
	result2.innerHTML = num2;
}





